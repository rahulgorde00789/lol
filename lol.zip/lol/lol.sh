kill `ps aux | grep c6th | grep -v "grep" | awk '{print $2}'`
